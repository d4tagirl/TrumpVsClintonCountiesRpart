library(testthat)
library(plotROC)

test_check("plotROC")
